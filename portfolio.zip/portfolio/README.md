# Personal Portfolio

This is my personal portfolio website showcasing my skills, experience, projects, and contact information.

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Sections
- About Me
- Professional Experience
- Education
- Skills
- Projects
- Contact

## Live Demo
[View Portfolio](https://venkyallaka.github.io/portfolio/)

## Getting Started
1. Clone the repository
2. Open `index.html` in your browser

## Author
Venkateswara Rao Allaka